Query From: {{$sender_name}}: {{$sender_email}},{{$sender_location}}
<br><br>
{{ $query }}