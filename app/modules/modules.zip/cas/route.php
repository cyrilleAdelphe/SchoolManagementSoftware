<?php

	include_once(app_path().'/modules/cas/grade-settings-route.php');
	include_once(app_path().'/modules/cas/sub-topics-route.php');
	include_once(app_path().'/modules/cas/remark-setting-route.php');