@extends('backend.'.$role.'.main')
@section('page-header')
  <h1 id = "export-to-excel-file_name">Income Report Student </h1>
@stop
@section('content')
<form method = "post" action = "{{URL::route('global-export-to-excel')}}" id = "export-to-excel-form">
  <a href = "#" class = "btn btn-success" id = "export-to-excel-button">Export To Excel</a>
<br>
<table  class="table table-bordered table-striped myData">
  <tbody>
    
    <tr class = "export-to-excel-row">
      <th class = "export-to-excel-data">Students</th>
      <th class = "export-to-excel-data">Total (without Credit Note)</th>
      @foreach($fee_titles as $f)
      @define $f = BillingHelperController::removeQuotesAndUnderScore($f)
      <th class = "export-to-excel-data">{{BillingHelperController::removeQuotesAndUnderScore($f)}}</th>
      @endforeach

      <th class = "export-to-excel-data">Credit Note</th>
      <th class = "export-to-excel-data">Unpaid Amount</th>
    </tr>
    @foreach($data['data'] as $student_names => $details)
    <tr class = "export-to-excel-row">
      <td class = "export-to-excel-data">{{$student_names}}</td>
      <td class = "export-to-excel-data">{{(float) $details['total']}}</td>
      @foreach($fee_titles as $f)
         
                @if(isset($details['fees'][$f]))
                  <td class = "export-to-excel-data">{{(float) $details['fees'][$f]}}</td>
                @else
                  <td class = "export-to-excel-data"> 0 </td>
                @endif
        
      @endforeach
      
      
      @define $credit_note = isset($data['credit_note'][$student_names]['total']) ? $data['credit_note'][$student_names]['total'] : 0
      <th class = "export-to-excel-data">{{$credit_note}}</th>
      <td class = "export-to-excel-data">{{(float) ($data['unpaid_amount'][$student_names] - $credit_note)}}</td>
    </tr>
    @endforeach

  </tbody>
</table>
</form>
@stop

@section('custom-js')
  <script src = "{{asset('backend-js/export-to-excel.js')}}"></script>
@stop

