<table class="table table-bordered table-striped myData" id = "transaction_table">
  <thead>
    <tr>
      <th>SN</th>
      <th>Transaction date</th>
      <th>Transaction no.</th>
      <th>Transaction type</th>
      <th>Invoice amount (CR)</th>
      <th>Invoice amount (DR)</th>
    </tr>
    <tr>
      <th></th>
      <th></th>
      <th></th>
      <th><input type = "text" id = "transaction_type" value = "" placeholder="filter..."></th>
      <th><p style="color:red;">Total: </p><div id="result_cr"></div></th>
      <th><p style="color:red;">Total: </p><div id="result_dr"></div></th>
    </tr>
  </thead>
  <tbody>
    @define $i = 0
    @foreach($data as $d)
    <tr>
      <tr>
        <td>{{++$i}}</td>
        <td>{{$d->transaction_date}}</td>
        <td><a href = "{{URL::route('show-invoice-from-transaction-number', $d->transaction_no)}}" data-lity>{{$d->transaction_no}}</a></td>

        <td class = "transaction_type_value">{{$d->transaction_type}}</td>
        @if(in_array($d->transaction_type, SsmConstants::$const_billing_types['credit']))
        <td class="invoice_cr">{{$d->transaction_amount}}</td>
        <td></td>
        @else
        <td></td>
        <td class="invoice_dr">{{$d->transaction_amount}}</td>
        @endif
      </tr>
      @endforeach
  </tbody>
</table>




