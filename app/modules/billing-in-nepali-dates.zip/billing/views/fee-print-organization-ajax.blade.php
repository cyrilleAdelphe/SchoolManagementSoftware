@if($return_data)
	<?php $sum = 0;?>
	@foreach($return_data as $student_id => $data)
	
	@if(isset($data['current_month']))
		@foreach($data['current_month'] as $d )
		

				@define $invoice_details = json_decode($d->invoice_details, true)
				
				<h4>{{$d->invoice_group_id}}</h4>

			<table>
				@foreach($invoice_details['fees'] as $f)
				<tr>
					<td><strong>Discount To: </strong></td>
					<td>{{$f['recipient']}}</td>
				</tr>
				<tr>
					<td><strong>Discount In: </strong></td>
					<td>{{$f['fee_title']}}</td>
				</tr>
				@endforeach
				<tr>
					<td><strong>Without Tax: </strong></td>
					<td>{{$invoice_details['summary']['sum_without_tax']}}</td>
				</tr>
				<tr>
					<td><strong>Tax: </strong></td>
					<td>{{$invoice_details['summary']['tax']}}</td>
				</tr>

				<tr>
					<td><strong>Tax: </strong></td>
					<td>{{$invoice_details['summary']['total']}}</td>
				</tr>
				<?php $sum = $sum + $invoice_details['summary']['total'] ?>
			</table>

	@endforeach
	@endif
	
	@if(isset($data['previous_month']))
		@foreach($data['previous_month'] as $d )

		<h3><u>Previous month discounts: </u></h3>
				
				@define $invoice_details = json_decode($d->invoice_details, true)
				<h4>{{$d->invoice_group_id}}</h4>
				<table>
				@foreach($invoice_details['fees'] as $f)
				<tr>
					<td><strong>Discount To: </strong></td>
					<td>{{$f['recipient']}}</td>
				</tr>
				<tr>
					<td><strong>Discount In: </strong></td>
					<td>{{$f['fee_title']}}</td>
				</tr>
				@endforeach
				<tr>
					<td><strong>Without Tax: </strong></td>
					<td>{{$invoice_details['summary']['sum_without_tax']}}</td>
				</tr>
				<tr>
					<td><strong>Tax: </strong></td>
					<td>{{$invoice_details['summary']['tax']}}</td>
				</tr>
				<tr>
					<td><strong>Tax: </strong></td>
					<td>{{$invoice_details['summary']['total']}}</td>
				</tr>
				<?php $sum = $sum + $invoice_details['summary']['total'] ?>
				</table>

		
	@endforeach
	@endif

@endforeach
<table>
	<tr>
		<td><strong>Total: </strong></td>
		<td><?php echo $sum;?></td>
	</tr>
</table>

@else
<h1>Invalid invoice</h1>

@endif

