<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	 <style>
	 	body{ font-family:arial; font-size: 12px; line-height: 20px }
	 	table { border-collapse: collapse;}
        table, td, th {  border: 1px solid #666;}
        .monthlyBill{width: 45%; display: block; float: left; overflow: hidden; }
        .invoiceFor{ line-height: 40px; font-weight: bold;  }
        .fHead{font-weight: bold; background-color: #ddd !important; text-align: left; padding-left: 5px}
        .fContent{text-align: left; padding-left: 5px}
        .tSum{display: block; clear: both; border-bottom: 1px solid #666; width: 70%; line-height: 20px; height: 20px; float: right;}
        .nextDiv{ margin-left: 10% }

		@media print
		{
			body{ font-family:arial; font-size: 12px; line-height: 20px }
			.fHead{ font-weight: bold; background-color: #ddd !important; -webkit-print-color-adjust: exact; text-align: left; padding-left: 5px }
			.pagebreak {  page-break-after: always !important;  }
		 	table, td, th {  border: 1px solid #666 !important;}
		}

	</style>
	<script  src="https://code.jquery.com/jquery-2.2.4.min.js"  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
	<script>
		$( document ).ready(function() {
			$(".monthlyBill:nth-child(even)").addClass("nextDiv");
		});
	</script>

</head>
<body>
	@if($return_data)
		
		<?php $block_data = array_chunk($return_data, 2); 
		?>

		@foreach($block_data as $return_data)
			<div class="mainHolder">
			@foreach($return_data as $student_id => $data)
			<?php $final_sum = 0; $a = 0; ?>
			@if(isset($data['current_month']))
				@foreach($data['current_month'] as $d )

						<?php $paid = $d->received_amount;?>
						@define $invoice_details = json_decode($d->invoice_details, true)
						
						<div class="monthlyBill"> 
								<div style="height: 55px; border-bottom: 1px solid #333; margin-bottom: 10px">
									<div style="float: left; width: 20%;">
										<img height="50" width="50" src="http://sajiloschoolmanager.com/sos_new/logo-fee.png"/>
									</div>
									<div style="float: left; width: 80%">
										<div style="line-height: 18px; font-size: 14px; font-weight: bold">
											Eton Technology Pvt. Ltd.
										</div>
										<div style=" line-height: 15px">
											Gyaneshwor - 32, Kathmandu<br/>
											Phone: 01 4413144
										</div>
									</div>
								</div>
								<div class="invoiceDetail">
									<div style="width: 40%; float: left;">
										Fiscal year: {{$d->financial_year}}
									</div>
									<div style="width: 40%; float: left;">
										Invoice No. {{$d->invoice_number}}
									</div>
								</div>
								<div class="invoiceFor">
									<div style="width: 45%; float: left;">
										{{$invoice_details['personal_details']['name']}}
										roll no. - {{$invoice_details['personal_details']['roll_number']}} /
										username - {{$d->username}} / 
										guardian - {{$d->guardian_name}} / 
										current address - {{$d->current_address}}
									</div>
									@define $date_and_class = explode('-', $d->invoice_group_id)
									<div style="width: 20%; float: left;">
										@if(isset($date_and_class[2])){{$date_and_class[2]}} @endif- @if(isset($date_and_class[3])){{$date_and_class[3]}} @endif
									</div>
									<div style="width: 35%; float: left; text-align: right; text-transform: capitalize;">
										Date: @if(isset($date_and_class[0])){{$date_and_class[0]}} @endif - @if(isset($date_and_class[1])){{$date_and_class[1]}} @endif

									</div>
								</div>
								<table  width="100%">
									<thead>
									<tr>
										<th class="fHead">SN</th>
										<th class="fHead">Title</th>
										<th class="fHead">Amount</th>
											@if($invoice_details['personal_details']['group'] == 'organization')
												<th>Recipient</th>
											@endif
									</tr>
									</thead>
									<tbody>
										@define $i = 0
										<?php $sum = 0;?>
										@foreach($invoice_details['fees'] as $fee)
											<tr>
												<td class="fContent">{{++$i}}</td>
												<td class="fContent">{{BillingHelperController::removeQuotesAndUnderScore($fee['fee_title'])}}</td>
												<td class="fContent">{{$fee['fee_amount']}}</td>
												@if($invoice_details['personal_details']['group'] == 'organization')
												<td class="fContent">{{$fee['recipient']}}</td>
												@endif
											</tr>
											<?php $sum =$fee['fee_amount'] + $sum ; ?>	
										@endforeach
										<thead>
											<tr>
												<th></th>
												<th class="fContent"><strong>Total</strong></th>
												<th class="fContent"><strong>{{$sum}}</strong></th>
											</tr>
										</thead>
									</tbody>
								</table>
								<br/>


								@if($invoice_details['personal_details']['group'] == 'student')
									@if(isset($invoice_details['discount']))

										@foreach($invoice_details['discount'] as $discount)
											<table width="100%">
												<thead>
													<tr>
														<th colspan="2" class="fHead">Discount Details</th>
													</tr>
												</thead>
												<tr>
													<td class="fContent"><strong>Org. Name</strong></td>
													<td class="fContent">{{$discount['organization_name']}} - {{$discount['discount_title']}}</td>
												</tr>
												<tr>
													<td class="fContent"><strong>Title</strong></td>
													<td class="fContent">{{$discount['fee_title']}}</td>
												</tr>
												<tr>
													<td class="fContent"><strong>Discount amount</strong></td>
													<td class="fContent">{{$discount['discount_amount']}}</td>
												</tr>
											</table>
											<br/>	
										@endforeach	
									@endif
								@endif
								<table width="100%">
									<thead>
										<tr>
											<th colspan="2" class="fHead">Total Details</th>
										</tr>
									</thead>
									<tr>
									<td class="fContent"><strong>Taxable Amount</strong></td>
									<td class="fContent">{{$invoice_details['summary']['taxable_amount']}}</td>
									</tr>
									<tr>
									<td class="fContent"><strong>Untaxable Amount</strong></td>
									<td class="fContent">{{$invoice_details['summary']['untaxable_amount']}}</td>
									</tr>
									<tr>
									<td class="fContent"><strong>Tax</strong></td>
									<td class="fContent">{{$invoice_details['summary']['tax']}}</td>
									</tr>
									<tr>
									<td class="fContent"><strong>Total</strong></td>
									<td class="fContent"><?php $a = $invoice_details['summary']['total'] - $paid;	echo $a; ?></td>
									</tr>
									<?php $final_sum =$d->invoice_balance + $final_sum - $paid; ?>
								</table>
							@endforeach
							@endif
							<br/>
								<div class="tSum">
									<div style="width: 70%; float: left"><strong>Total Of This Month:</strong></div>
									<div style="width: 30%; float: left">{{$final_sum}}</div>
								</div>
							@if(isset($data['previous_month']))

							@define $previous_due = 0
							@foreach($data['previous_month'] as $d)
								<?php $previous_due += $d->invoice_balance - $d->received_amount; ?>
								@define $invoice_details_previous = json_decode($d->invoice_details, true)
										<?php $final_sum = $d->invoice_balance + $final_sum - $d->received_amount; ?>
								@endforeach
								<div class="tSum">
									<div style="width: 70%; float: left"><strong>Previous Balance:</strong></div> 
									<div style="width: 30%; float: left">{{$previous_due}}</div>
								</div>
							@endif
								<div class="tSum">
									<div style="width: 70%; float: left"><strong>Grand Total:</strong></div>
									<div style="width: 30%; float: left">{{$final_sum}}</div>
								</div>
						</div><!-- monthly bill ends -->		
										
						@endforeach
						</div><!-- main holder -->
						<div class="pagebreak">&nbsp;</div>
					@endforeach


	@else
	<h1>Invalid invoice</h1>
	@endif
	
</body>
</html>